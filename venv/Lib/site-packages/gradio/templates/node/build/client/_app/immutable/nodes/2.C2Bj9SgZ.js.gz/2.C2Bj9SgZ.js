import{Z as e,_ as n}from"../chunks/2.D6HX3nth.js";export{e as component,n as universal};
//# sourceMappingURL=2.C2Bj9SgZ.js.map
