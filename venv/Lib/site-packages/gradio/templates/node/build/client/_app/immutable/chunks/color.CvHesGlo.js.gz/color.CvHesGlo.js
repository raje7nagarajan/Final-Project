import{v as o}from"./2.D6HX3nth.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.CvHesGlo.js.map
