import{P as c,a as r}from"./mermaid-parser.core.DEJGjNwf.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.C26aaYiK.js.map
