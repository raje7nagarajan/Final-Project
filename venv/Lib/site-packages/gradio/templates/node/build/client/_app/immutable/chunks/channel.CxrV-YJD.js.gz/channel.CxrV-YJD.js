import{U as a,C as n}from"./mermaid.core.BLhpPCEP.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.CxrV-YJD.js.map
